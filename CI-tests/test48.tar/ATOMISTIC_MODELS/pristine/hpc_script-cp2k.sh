#!/bin/bash
## Submission script for scarf
#SBATCH --comment=ALC_EQCM    # Project name
#SBATCH --job-name=Al2O3    # job name
#SBATCH -o %J.out
#SBATCH -e %J.err
#SBATCH --time=1-04:37:00        # days-hh:mm:ss
#
#SBATCH --mem-per-cpu=600  # Megabytes
#SBATCH --partition=preemptable    # queue (partition)
#SBATCH --ntasks=48
#SBATCH --nodes=4
#SBATCH --ntasks-per-node=12
#SBATCH --cpus-per-task=2
 
export OMP_NUM_THREADS=2
 
## Load required modules
module load modulo1
module load modulo2
 
## Define executable
exec="path/to/code/executable.x"
 
## Execute job
mpirun -np 48 $exec -i input.cp2k -o output.cp2k
