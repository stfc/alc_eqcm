#!/bin/bash
## Submission script for scarf
#SBATCH --comment=ALC_EQCM    # Project name
#SBATCH --job-name=NiO2H2    # job name
#SBATCH -o %J.out
#SBATCH -e %J.err
#SBATCH --time=03:59:00        # hh:mm:ss
#
#SBATCH --mem-per-cpu=600  # Megabytes
#SBATCH --partition=preemptable    # queue (partition)
#SBATCH --ntasks=24          
#SBATCH --nodes=1           
#SBATCH --ntasks-per-node=24          
 
## Load required modules
module load castep/18.1
 
## Define executable
exec="castep.mpi"
 
## Execute job
mpirun -np 24 $exec model
