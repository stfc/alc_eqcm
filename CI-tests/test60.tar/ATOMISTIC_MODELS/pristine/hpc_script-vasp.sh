#!/bin/bash
## Submission script for scarf
#SBATCH --comment=ALC_EQCM    # Project name
#SBATCH --job-name=Al2O3    # job name
#SBATCH -o %J.out
#SBATCH -e %J.err
#SBATCH --time=1-04:37:00        # days-hh:mm:ss
#
#SBATCH --partition=preemptable    # queue (partition)
#SBATCH --ntasks=48          
#SBATCH --nodes=2           
#SBATCH --ntasks-per-node=24          
 
## Load required modules
module load modulo1
module load modulo2
 
## Define executable
exec="path/to/code/executable.x"
 
## Execute job
mpirun -np 48 $exec
