#!/bin/bash
## Submission script for scarf
#SBATCH --comment=ALC_EQCM    # Project name
#SBATCH --job-name=NiO2H2    # job name
#SBATCH -o %J.out
#SBATCH -e %J.err
#SBATCH --time=2-17:13:00        # days-hh:mm:ss
#
#SBATCH --partition=scarf    # queue (partition)
#SBATCH --ntasks=24          
#SBATCH --nodes=1           
#SBATCH --ntasks-per-node=24          
 
## Load required modules
module load vasp/5.4.4
 
## Define executable
exec="vasp"
 
## Execute job
mpirun -np 24 $exec
