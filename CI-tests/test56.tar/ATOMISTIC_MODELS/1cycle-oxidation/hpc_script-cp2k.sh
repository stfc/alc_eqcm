#!/bin/bash
## Submission script for scarf
#SBATCH --comment=ALC_EQCM    # Project name
#SBATCH --job-name=NiO2H2    # job name
#SBATCH -o %J.out
#SBATCH -e %J.err
#SBATCH --time=03:59:00        # hh:mm:ss
#
#SBATCH --mem-per-cpu=600  # Megabytes
#SBATCH --partition=preemptable    # queue (partition)
#SBATCH --ntasks=24
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=12
#SBATCH --cpus-per-task=2
 
export OMP_NUM_THREADS=2
 
## Load required modules
 
## Define executable
exec=""
 
## Execute job
mpirun -np 24 $exec -i input.cp2k -o output.cp2k
