#!/bin/bash
## Submission script for scarf
#SBATCH --comment=ALC_EQCM    # Project name
#SBATCH --job-name=NiO2H2    # job name
#SBATCH -o %J.out
#SBATCH -e %J.err
#SBATCH --time=07:01:00        # hh:mm:ss
#
#SBATCH --partition=scarf    # queue (partition)
#SBATCH --ntasks=96          
#SBATCH --nodes=4           
#SBATCH --ntasks-per-node=24          
export MKL_NUM_THREADS=1
 
## Load required modules
module load vasp/5.4.4
 
## Define executable
exec="vasp"
 
## Execute job
mpirun -np 96 $exec
